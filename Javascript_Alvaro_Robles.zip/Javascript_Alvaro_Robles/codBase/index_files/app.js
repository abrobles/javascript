var calculadora = {
	numero: 0,
	num_adi: "",
	punto:"",
	signo:false,
	operando1:0,
	operando2:0,
	operacion:"",

	igual: function() {

		this.operando2=parseFloat(this.num_adi);

		if(this.operando1!=0 && this.operando2!=0)
		{
		
		if(this.operacion=="mas")
			{ this.numero = this.operando1+this.operando2; }
		else if(this.operacion=="menos")
			{ this.numero = this.operando1-this.operando2; }
		else if(this.operacion=="por")
			{ this.numero = this.operando1*this.operando2; }
		else if(this.operacion=="dividido")
			{ this.numero = this.operando1/this.operando2; }
		
		this.operando1=this.numero;
		this.operando2=0;
		this.num_adi=""+this.numero;

		return this.num_adi.substring(0, 8);
		}		

		return "0";
	},

	operando: function(opera) {

		this.operacion=opera;

		if(this.operando1==0)
		{
		 if(this.num_adi=="")
		 {
		 this.operando1=0;
		 }
		 else
		 {
		 this.operando1=parseFloat(this.num_adi);
		 this.num_adi="";
		 return this.num_adi;
		 }
		}
		else 
		{
		 if(this.num_adi=="")
		 {
		 this.operando2=0;
		 }
		 else
		 {
		 this.operando2=parseFloat(this.num_adi);
		 this.num_adi="";
		 return this.num_adi;
		 }
		}

	},

	adicionarSigno: function(num) {
		if(this.num_adi.length==8)
		{
		return this.num_adi;
		}
		else if(this.numero==0 && (this.num_adi=="" || this.num_adi=="0"))
		{
		 return "0";
		}
		else if(this.signo) 
		{
		this.num_adi=this.num_adi.substr(1,this.num_adi.length);
		this.signo=false;
		}		
		else
		{
		this.num_adi=num+this.num_adi;
		this.signo=true;
		}
		
		return this.num_adi;
	},

	adicionarNumero: function(num) {
		if(this.num_adi.length==8)
		{
		return this.num_adi;
		}
		else if(this.num_adi=="0" && num=="0")
		{
		return this.num_adi;
		}
		else if(this.num_adi=="0" && num!="0")
		{
		this.num_adi=num;
		return this.num_adi;
		}
		else if(this.numero==0) 
		{
			if(this.punto=="" && num==".")
			{
			this.num_adi = this.num_adi+num;
			this.punto=".";
			}
			else if(this.punto=="." && num!=".")
			{
			this.num_adi = this.num_adi+num;
			}
			else if(num==".")
			{
			this.num_adi = this.num_adi;
			}
			else 
				{
				this.num_adi = this.num_adi+num;
				}
		}
		else
		{
			if(this.punto=="" && num==".")
			{
			this.num_adi = this.num_adi+num;
			this.punto=".";
					}
			else if(num==".")
			{
			this.num_adi = this.num_adi;
			}
			else 
				{
				this.num_adi = this.num_adi+num;
				}
		}
		this.numero = num;

		return this.num_adi;
	},

	borrarNumero: function() {
		this.num_adi="";
		this.numero = 0;
		this.punto="";
		this.operando1 = 0;
		this.operando2 = 0;

		return "0";
	}
};


function adicionarSignos(digito) {
		
		document.getElementById("display").innerText = calculadora.adicionarSigno(digito);
	
};

function borrarDigitos() {
		
		document.getElementById("display").innerText = calculadora.borrarNumero();
};

function operandoDigitos(opera) {
		
		document.getElementById("display").innerText = calculadora.operando(opera);
};

function igualDigitos() {
		
		document.getElementById("display").innerText = calculadora.igual();
};

function adicionarDigito(digito)
{
    document.getElementById("display").innerText = calculadora.adicionarNumero(digito);
};

function reducirBoton(digito)
{
    document.getElementById(digito).style="width:21%;";
};

function aumentarBoton(digito)
{
    document.getElementById(digito).style="width:22%;";
};


function reducirBoton2(digito)
{
    document.getElementById(digito).style="width:28%;";
};

function aumentarBoton2(digito)
{
    document.getElementById(digito).style="width:29%;";
};


function reducirBoton3(digito)
{
    document.getElementById(digito).style="width:85%;";
};

function aumentarBoton3(digito)
{
    document.getElementById(digito).style="width:100%;";
};



document.getElementById("9").addEventListener("click", function(){adicionarDigito("9")}); 

document.getElementById("9").addEventListener("mouseup", function(){aumentarBoton("9")}); 

document.getElementById("9").addEventListener("mousedown", function(){reducirBoton("9")}); 


document.getElementById("8").addEventListener("click", function(){adicionarDigito("8")}); 

document.getElementById("8").addEventListener("mouseup", function(){aumentarBoton("8")}); 

document.getElementById("8").addEventListener("mousedown", function(){reducirBoton("8")}); 


document.getElementById("7").addEventListener("click", function(){adicionarDigito("7")}); 

document.getElementById("7").addEventListener("mouseup", function(){aumentarBoton("7")}); 

document.getElementById("7").addEventListener("mousedown", function(){reducirBoton("7")}); 


document.getElementById("6").addEventListener("click", function(){adicionarDigito("6")}); 

document.getElementById("6").addEventListener("mouseup", function(){aumentarBoton("6")}); 

document.getElementById("6").addEventListener("mousedown", function(){reducirBoton("6")}); 


document.getElementById("5").addEventListener("click", function(){adicionarDigito("5")}); 

document.getElementById("5").addEventListener("mouseup", function(){aumentarBoton("5")}); 

document.getElementById("5").addEventListener("mousedown", function(){reducirBoton("5")}); 


document.getElementById("4").addEventListener("click", function(){adicionarDigito("4")}); 

document.getElementById("4").addEventListener("mouseup", function(){aumentarBoton("4")}); 

document.getElementById("4").addEventListener("mousedown", function(){reducirBoton("4")}); 


document.getElementById("3").addEventListener("click", function(){adicionarDigito("3")}); 

document.getElementById("3").addEventListener("mouseup", function(){aumentarBoton2("3")}); 

document.getElementById("3").addEventListener("mousedown", function(){reducirBoton2("3")}); 


document.getElementById("2").addEventListener("click", function(){adicionarDigito("2")}); 

document.getElementById("2").addEventListener("mouseup", function(){aumentarBoton2("2")}); 

document.getElementById("2").addEventListener("mousedown", function(){reducirBoton2("2")}); 


document.getElementById("1").addEventListener("click", function(){adicionarDigito("1")}); 

document.getElementById("1").addEventListener("mouseup", function(){aumentarBoton2("1")}); 

document.getElementById("1").addEventListener("mousedown", function(){reducirBoton2("1")}); 


document.getElementById("0").addEventListener("click", function(){adicionarDigito("0")}); 

document.getElementById("0").addEventListener("mouseup", function(){aumentarBoton2("0")}); 

document.getElementById("0").addEventListener("mousedown", function(){reducirBoton2("0")}); 


document.getElementById("punto").addEventListener("click", function(){adicionarDigito(".")}); 

document.getElementById("punto").addEventListener("mouseup", function(){aumentarBoton2("punto")}); 

document.getElementById("punto").addEventListener("mousedown", function(){reducirBoton2("punto")}); 


document.getElementById("sign").addEventListener("click", function(){adicionarSignos("-")}); 

document.getElementById("sign").addEventListener("mouseup", function(){aumentarBoton("sign")}); 

document.getElementById("sign").addEventListener("mousedown", function(){reducirBoton("sign")}); 


document.getElementById("on").addEventListener("click", function(){borrarDigitos()}); 

document.getElementById("on").addEventListener("mouseup", function(){aumentarBoton("on")}); 

document.getElementById("on").addEventListener("mousedown", function(){reducirBoton("on")}); 


document.getElementById("igual").addEventListener("click", function(){igualDigitos()}); 

document.getElementById("igual").addEventListener("mouseup", function(){aumentarBoton2("igual")}); 

document.getElementById("igual").addEventListener("mousedown", function(){reducirBoton2("igual")}); 


document.getElementById("mas").addEventListener("click", function(){operandoDigitos("mas")}); 

document.getElementById("mas").addEventListener("mouseup", function(){aumentarBoton3("mas")});

document.getElementById("mas").addEventListener("mousedown", function(){reducirBoton3("mas")}); 


document.getElementById("menos").addEventListener("click", function(){operandoDigitos("menos")}); 

document.getElementById("menos").addEventListener("mouseup", function(){aumentarBoton("menos")}); 

document.getElementById("menos").addEventListener("mousedown", function(){reducirBoton("menos")}); 


document.getElementById("por").addEventListener("click", function(){operandoDigitos("por")}); 

document.getElementById("por").addEventListener("mouseup", function(){aumentarBoton("por")}); 

document.getElementById("por").addEventListener("mousedown", function(){reducirBoton("por")}); 


document.getElementById("dividido").addEventListener("click", function(){operandoDigitos("dividido")}); 

document.getElementById("dividido").addEventListener("mouseup", function(){aumentarBoton("dividido")}); 

document.getElementById("dividido").addEventListener("mousedown", function(){reducirBoton("dividido")}); 